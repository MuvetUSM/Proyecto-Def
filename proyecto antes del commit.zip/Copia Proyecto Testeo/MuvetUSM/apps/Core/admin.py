from django.contrib import admin
from .models import Usuario, Asignatura

# Register your models here.
admin.site.register(Usuario)
admin.site.register(Asignatura)